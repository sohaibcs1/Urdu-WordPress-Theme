$(document).ready(function(){

  $('.newsTicker').liMarquee({
  		direction: 'right',
  		drag: false,
  		scrollamount: 15,
  		circular: true,
  });
  
  $('.archive-post-grid').matchHeight();
  $('.block-post-grid').matchHeight();
  $('.home-grid-block').matchHeight();
  $('.footer-widget-col').matchHeight();

  $('#SearchO').click(function(){
  	$(".search-box").fadeIn('normal');
  });

  $('#closeSearchBox').click(function(){
  	$(".search-box").fadeOut('normal');
  });

  $(".grid-post-link pre").focus(function() { this.select(); });

});