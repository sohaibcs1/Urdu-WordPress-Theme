function store_rating(ip,post_id,value) {
	var postID = post_id;
	var userIP = ip;
	var ratVal = value;
	
	jQuery.ajax({
		url : my_ajax_url.ajax_url,
		type : 'post',
		data : {
			action : 'my_ajax_function',
			id : postID,
			ip : userIP,
			val : ratVal
		},
		success : function( response ) {
			jQuery('#rating-ajax-response').fadeIn("normal");
			jQuery('#rating-ajax-response').html( response );
		}
	});
}