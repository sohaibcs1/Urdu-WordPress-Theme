<?php
/**
 * The template for displaying archive pages.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package UrduPaper
 */

get_header(); ?>

	<div id="primary" class="archive-content content-area">
		<div id="main" class="archive-main" role="main">

			<?php
			if ( have_posts() ) : ?>

				<header class="page-header">
					<?php
						echo '<h1 class="page-title">';single_cat_title();echo '</h1>';
					?>
				</header><!-- .page-header -->
				<div class="archive-posts-container">
					<?php
					/* Start the Loop */
					while ( have_posts() ) : the_post();

						get_template_part( 'template-parts/content', 'archive' );

					endwhile;
					?>
				</div>
				<div class="pagination-container">
				<?php if ( function_exists( 'uppaper_page_navi' ) ) { 
					uppaper_page_navi(); 
				 } else { 
						the_posts_navigation(); 
				 	} 
				 ?>
				 </div>
			<?php 

			else :

				get_template_part( 'template-parts/content', 'none' );

			endif; ?>

		</div><!-- #main -->

	</div><!-- #primary -->

<?php
get_footer();
