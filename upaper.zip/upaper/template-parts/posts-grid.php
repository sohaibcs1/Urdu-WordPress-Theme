<div class="home-grid-block-inner">
<div class="block-head grid-block-head">
	<h2><span class="block-head-icon pull-right"><i class="fa <?php echo $block_icon ?>"></i></span> <span class="title-text pull-right mr-10"><?php echo get_cat_name( $block_cat ) ?></span> </h2>
</div>
<div class="block-body">
<?php
global $xpanel;
// The Query
$i = 1;
$args = array(
	'cat' => $block_cat,
	'posts_per_page' => $xpanel['homepage-grid-count']
);
$posts_query = new WP_Query( $args );

// The Loop
if ( $posts_query->have_posts() ) {
	while ( $posts_query->have_posts() ) {
		$posts_query->the_post(); ?>
		<?php if($i == 1) { ?>
		<div class="mb-10 block-post-first col-lg-16 col-md-16 col-sm-16 col-xs-16 pr-0 pl-0">
			<div class="post-content">
				<div class="block-post-row">
					<a href="<?php the_permalink() ?>">
					<?php
						if ( has_post_thumbnail() ) {
							the_post_thumbnail('postblock-grid');
						}
						else {
							echo '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/nothumb.png" />';
						}
					?>
					</a>
				</div>
				<div class="block-post-row">
					<h5 class="pb-5"><a href="<?php the_permalink() ?>"><?php the_title() ?></a></h5>
					<div class="post-info pt-5 pb-5">
						<?php 
							if ( isset( $xpanel['show-comment-count'] ) && $xpanel['show-comment-count'] == TRUE ) {
						?>
						<small><?php $comments_count = wp_count_comments(get_the_ID()); ?></small>
						<?php } ?>
						<?php 
							if ( isset( $xpanel['show-posted-date'] ) && $xpanel['show-posted-date'] == TRUE ) {
						?>
						<?php upaper_posted_on() ?>
						<?php } ?>
						<?php 
							if ( isset( $xpanel['show-comment-count'] ) && $xpanel['show-comment-count'] == TRUE ) {
						?>
						<span class="post-comments mr-10">
							<i class="fa fa-comment-o pl-5"></i> <?php echo $comments_count->approved ?> <?php _e("تبصرے") ?>
						</span>
						<?php } ?>
						<?php 
							if ( isset( $xpanel['show-views'] ) && $xpanel['show-views'] == TRUE ) {
						?>
						<span class="post-views mr-10"><i class="fa fa-eye pl-5"></i> <small><?php echo getViews(get_the_ID()) ?></small> <?php _e("مناظر") ?></span>
						<?php } ?>
					</div>

				</div>
				
			</div>
		</div>
		<?php } else { ?>
		<div class="pb-5 mb-10 block-post-smallrow col-lg-16 col-md-16 col-sm-16 col-xs-16 pl-0 pr-0">
			<div class="post-content">
				<div class="col-lg-4 col-md-5 col-sm-5 col-xs-3 pull-right pr-0">
					<a href="<?php the_permalink() ?>">
					<?php
						if ( has_post_thumbnail() ) {
							the_post_thumbnail('postblock-small');
						}
						else {
							echo '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/nothumb.png" />';
						}
					?>
					</a>
				</div>
				<div class="col-lg-12 col-md-11 col-sm-11 col-xs-13 pl-0 pr-0">
					<h6 class="blokpost-title">
						<a href="<?php the_permalink() ?>">
							<?php
								$trimtitle = get_the_title(); 
								$shorttitle = wp_trim_words( $trimtitle, $num_words = 12, $more = '… ' ); 
								echo $shorttitle;
							?>
						</a>
					</h6>
				</div>
			</div>
		</div>
		<?php } ?>
	<?php
	$i++; }
} else {
	// no posts found
}
/* Restore original Post Data */
wp_reset_postdata();

?>
</div>
</div>