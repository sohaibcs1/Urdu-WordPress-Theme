<?php
global $xpanel;
$args = array(
	'cat' => $xpanel['carousel-cat'],
	'posts_per_page' => $xpanel['carousel-count']
);
$posts_query = new WP_Query( $args );

// The Loop
if ( $posts_query->have_posts() ) {
	while ( $posts_query->have_posts() ) {
		$posts_query->the_post(); ?>
		
		<div>
			<div class="carousel-thumb col-lg-16 col-md-16 col-sm-16 col-xs-16">
				<a href="<?php the_permalink() ?>">
					<?php 
					if ( has_post_thumbnail() ) {
						the_post_thumbnail('postblock-carousel');
					}
					else {
						echo '<img src="' . get_bloginfo( 'stylesheet_directory' ) . '/images/nothumb-carousel.jpg" />';
					}
					?>
					<?php if($xpanel['show-overlay'] == TRUE) {  ?>
					<span class="overlay"><i class="fa fa-play-circle-o"></i></span>
					<?php } ?>
				</a>
			</div>
		</div>
	<?php
	}
} else {
	// no posts found
}
/* Restore original Post Data */
wp_reset_postdata();

?>
