<div class="block-head">
	<h2><?php echo get_cat_name( $block_cat ) ?></h2>
</div>
<div class="block-body">
<?php
global $xpanel;
$args = array(
	'cat' => $block_cat,
	'posts_per_page' => $xpanel['homepage-block2-count']
);
$posts_query = new WP_Query( $args );

// The Loop
if ( $posts_query->have_posts() ) {
	while ( $posts_query->have_posts() ) {
		$posts_query->the_post(); ?>
		
		<div class="pr-0 mb-10 col-lg-8 col-md-8 col-sm-8 col-xs-16">
			<div class="column-post-title pr-0 col-lg-11 col-md-11 col-sm-11 col-xs-11">
				<a href="<?php the_permalink() ?>">
					<?php
						$trimtitle = get_the_title(); 
						$shorttitle = wp_trim_words( $trimtitle, $num_words = 12, $more = '… ' ); 
						echo $shorttitle;
					?>
				</a>
			</div>
			<div class="column-post-thumb pr-0 col-lg-5 col-md-5 col-sm-5 col-xs-5">
				<?php the_post_thumbnail('postblock-small') ?>
			</div>
		</div>
	<?php
	}
} else {
	// no posts found
}
/* Restore original Post Data */
wp_reset_postdata();

?>
</div>