<?php
/**
 * Template part for displaying news ticker.
 *
 * @package UrduPaper
 */
// The Query
$ticker_query = new WP_Query( 'cat='.$news_cat.'&showposts='.$news_limit.'' );

// The Loop
if ( $ticker_query->have_posts() ) {
	while ( $ticker_query->have_posts() ) {
		$ticker_query->the_post(); ?>
		<a href="<?php the_permalink() ?>"><span id="news-star-sign" class="animated infinite flash"></span><?php the_title() ?></a>
	<?php }
} else {
	// no posts found
}
/* Restore original Post Data */
wp_reset_postdata();
?>