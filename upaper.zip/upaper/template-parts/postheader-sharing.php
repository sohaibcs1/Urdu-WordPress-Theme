<?php
/**
 * Template part for displaying sharing icons.
 *
 * @package UrduPaper
 */
global $xpanel;
$current_url = home_url(add_query_arg(array(),$wp->request));
$icon_styles = $xpanel['sharing-icons-style'];
?>
<ul>
	<li>
		<a href="http://www.facebook.com/sharer.php?u=<?php echo $current_url ?>" target="_blank" class="<?php echo $icon_styles ?>" id="fb">
			<i class="fa fa-facebook"></i>
		</a>
	</li>
	<li>
		<a href="https://twitter.com/share?url=<?php echo $current_url ?>" target="_blank" class="<?php echo $icon_styles ?>" id="tw">
			<i class="fa fa-twitter"></i>
		</a>
	</li>
	<li>
		<a href="https://plus.google.com/share?url=<?php echo $current_url ?>" target="_blank" class="<?php echo $icon_styles ?>" id="gp">
			<i class="fa fa-google-plus"></i>
		</a>
	</li>
	<li>
		<a href="javascript:void((function()%7Bvar%20e=document.createElement('script');e.setAttribute('type','text/javascript');e.setAttribute('charset','UTF-8');e.setAttribute('src','http://assets.pinterest.com/js/pinmarklet.js?r='+Math.random()*99999999);document.body.appendChild(e)%7D)());" class="<?php echo $icon_styles ?>" id="pn">
			<i class="fa fa-pinterest"></i>
		</a>
	</li>
	<li>
		<a href="http://www.linkedin.com/shareArticle?mini=true&url=<?php echo $current_url ?>" target="_blank" class="<?php echo $icon_styles ?>" id="li">
			<i class="fa fa-linkedin"></i>
		</a>
	</li>
	<li>
		<a href="http://reddit.com/submit?url=<?php echo $current_url ?>" target="_blank" class="<?php echo $icon_styles ?>" id="rdt">
			<i class="fa fa-reddit"></i>
		</a>
	</li>
	<li>
		<a href="http://www.stumbleupon.com/submit?url=<?php echo $current_url ?>" target="_blank" class="<?php echo $icon_styles ?>" id="su">
			<i class="fa fa-stumbleupon"></i>
		</a>
	</li>
</ul>