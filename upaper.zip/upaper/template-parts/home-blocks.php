<?php
/**
 * Template part for displaying posts.
 *
 * @package Urdu Paper
 */
global $xpanel;
?>
<?php if($xpanel['show-classic'] == TRUE) { ?>
<div class="row mb-20">
	<div class="block-sidebar pl-0 col-lg-5 col-md-5 col-sm-6 hidden-xs">
	<?php dynamic_sidebar('sidebar-1') ?>
	</div>
	<div class="classic-block pr-0 col-lg-11 col-md-11 col-sm-10 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-block-1'];
			set_query_var( 'block_cat', $block_cat );
			get_template_part( 'template-parts/posts', 'block' );
		?>
	</div>
	<div class="block-sidebar pl-0 pr-0 hidden-lg hidden-md hidden-sm col-xs-16">
	<?php dynamic_sidebar('sidebar-1') ?>
	</div>
</div>
<?php } ?>
<?php if($xpanel['show-columns'] == TRUE) { ?>
<div class="row">
	<div class="columns-block pl-0 col-lg-11 col-md-11 col-sm-16 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-block-2'];
			set_query_var( 'block_cat', $block_cat );
			get_template_part( 'template-parts/posts', 'columns' );
		?>
	</div>
	<div class="block-sidebar pr-0 pl-0 col-lg-5 col-md-5 col-sm-16 col-xs-16">
	<?php dynamic_sidebar('sidebar-2') ?>
	</div>
</div>
<?php } ?>
<div class="row banner-row">
	<?php dynamic_sidebar('ad-block1') ?>
</div>
<?php if($xpanel['show-carousel'] == TRUE) { ?>
<div class="row carousel-row mb-20 mt-10">
	<div class="carousel-container">
		<div class="carousel-left"></div>
		<div class="carousel-content home-carousel">
			<?php get_template_part( 'template-parts/posts', 'carousel' ); ?>	
		</div>
		<div class="carousel-right"></div>
		<div class="carousel-arrows"></div>
	</div>
</div>
<?php } ?>
<div class="row home-grid-row">
	<div class="home-grid-block pl-0 col-lg-5 col-md-5 col-sm-16 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-grid-3'];
			$block_icon = $xpanel['homepage-grid-icon-3'];
			set_query_var( 'block_cat', $block_cat );
			set_query_var( 'block_icon', $block_icon );
			get_template_part( 'template-parts/posts', 'grid' );
		?>
	</div>
	<div class="home-grid-block center-block col-lg-5 col-md-5 col-sm-16 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-grid-2'];
			$block_icon = $xpanel['homepage-grid-icon-2'];
			set_query_var( 'block_cat', $block_cat );
			set_query_var( 'block_icon', $block_icon );
			get_template_part( 'template-parts/posts', 'grid' );
		?>
	</div>
	<div class="home-grid-block pr-0 col-lg-5 col-md-5 col-sm-16 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-grid-1'];
			$block_icon = $xpanel['homepage-grid-icon-1'];
			set_query_var( 'block_cat', $block_cat );
			set_query_var( 'block_icon', $block_icon );
			get_template_part( 'template-parts/posts', 'grid' );
		?>
	</div>
</div>
<div class="row banner-row">
	<?php dynamic_sidebar('ad-block2') ?>
</div>
<?php 
if($xpanel['homepage-grids-count'] > 3) {
?>
<div class="row home-grid-row">
	<div class="home-grid-block pl-0 col-lg-5 col-md-5 col-sm-16 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-grid-6'];
			$block_icon = $xpanel['homepage-grid-icon-6'];
			set_query_var( 'block_cat', $block_cat );
			set_query_var( 'block_icon', $block_icon );
			get_template_part( 'template-parts/posts', 'grid' );
		?>
	</div>
	<div class="home-grid-block center-block col-lg-5 col-md-5 col-sm-16 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-grid-5'];
			$block_icon = $xpanel['homepage-grid-icon-5'];
			set_query_var( 'block_cat', $block_cat );
			set_query_var( 'block_icon', $block_icon );
			get_template_part( 'template-parts/posts', 'grid' );
		?>
	</div>
	<div class="home-grid-block pr-0 col-lg-5 col-md-5 col-sm-16 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-grid-4'];
			$block_icon = $xpanel['homepage-grid-icon-4'];
			set_query_var( 'block_cat', $block_cat );
			set_query_var( 'block_icon', $block_icon );
			get_template_part( 'template-parts/posts', 'grid' );
		?>
	</div>
</div>
<?php } ?>
<div class="row banner-row">
	<?php dynamic_sidebar('ad-block1') ?>
</div>
<?php 
if($xpanel['homepage-grids-count'] > 6) {
?>
<div class="row home-grid-row">
	<div class="home-grid-block pl-0 col-lg-5 col-md-5 col-sm-16 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-grid-9'];
			$block_icon = $xpanel['homepage-grid-icon-9'];
			set_query_var( 'block_cat', $block_cat );
			set_query_var( 'block_icon', $block_icon );
			get_template_part( 'template-parts/posts', 'grid' );
		?>
	</div>
	<div class="home-grid-block center-block col-lg-5 col-md-5 col-sm-16 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-grid-8'];
			$block_icon = $xpanel['homepage-grid-icon-8'];
			set_query_var( 'block_cat', $block_cat );
			set_query_var( 'block_icon', $block_icon );
			get_template_part( 'template-parts/posts', 'grid' );
		?>
	</div>
	<div class="home-grid-block pr-0 col-lg-5 col-md-5 col-sm-16 col-xs-16">
		<?php 
			$block_cat = $xpanel['homepage-grid-7'];
			$block_icon = $xpanel['homepage-grid-icon-7'];
			set_query_var( 'block_cat', $block_cat );
			set_query_var( 'block_icon', $block_icon );
			get_template_part( 'template-parts/posts', 'grid' );
		?>
	</div>
</div>
<?php } ?>