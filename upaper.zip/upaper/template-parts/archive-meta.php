<?php 
 global $xpanel;
?>
<div class="post-info pt-5 pb-5">
	<?php 
		if ( isset( $xpanel['show-comment-count'] ) && $xpanel['show-comment-count'] == TRUE ) {
	?>
	<span class="post-comments pull-right">
		<small><?php $comments_count = wp_count_comments(get_the_ID()); ?></small>
	</span>
	<?php } ?>
	<?php 
		if ( isset( $xpanel['show-posted-date'] ) && $xpanel['show-posted-date'] == TRUE ) {
	?>
	<?php upaper_posted_on() ?>
	<?php } ?>
	<?php 
		if ( isset( $xpanel['show-comment-count'] ) && $xpanel['show-comment-count'] == TRUE ) {
	?>
	<span class="post-comments pull-right mr-10">
		<i class="fa fa-comment-o pl-5"></i> <?php echo $comments_count->approved ?> <?php _e("تبصرے") ?>
	</span>
	<?php } ?>
	<?php 
		if ( isset( $xpanel['show-views'] ) && $xpanel['show-views'] == TRUE ) {
	?>
	<span class="post-views pull-right mr-10"><i class="fa fa-eye pl-5"></i> <small><?php echo getViews(get_the_ID()) ?></small> <?php _e("مناظر") ?></span>
	<?php } ?>
</div>