<?php 
$ip_address = get_client_ip_server();
$post_id = get_the_ID();
?>
<div class="block-body">

	<ul class="rating-list">
		<li>
			<a href="javascript:" onclick="store_rating('<?php echo $ip_address ?>', '<?php echo $post_id ?>', '1')">
				<span class="rating-icon"><i class="icon-emo-angry"></i></span>
				<span class="rating-text"><?php _e('سخت نا پسند') ?></span>
				<span class="rating-result"><?php echo get_votes_count(''.$post_id.'','1') ?> Votes</span>
			</a>
		</li>
		<li>
			<a href="javascript:" onclick="store_rating('<?php echo $ip_address ?>', '<?php echo $post_id ?>', '2')">
				<span class="rating-icon"><i class="icon-emo-sleep"></i></span>
				<span class="rating-text"><?php _e('بہتر ہو سکتی تھی') ?></span>
				<span class="rating-result"><?php echo get_votes_count(''.$post_id.'','2') ?> Votes</span>
			</a>
		</li>
		<li>
			<a href="javascript:" onclick="store_rating('<?php echo $ip_address ?>', '<?php echo $post_id ?>', '3')">
				<span class="rating-icon"><i class="icon-emo-wink2"></i></span>
				<span class="rating-text"><?php _e('ٹھیک ہے') ?></span>
				<span class="rating-result"><?php echo get_votes_count(''.$post_id.'','3') ?> Votes</span>
			</a>
		</li>
		<li>
			<a href="javascript:" onclick="store_rating('<?php echo $ip_address ?>', '<?php echo $post_id ?>', '4')">
				<span class="rating-icon"><i class="icon-emo-happy"></i></span>
				<span class="rating-text"><?php _e('اچھی ہے') ?></span>
				<span class="rating-result"><?php echo get_votes_count(''.$post_id.'','4') ?> Votes</span>
			</a>
		</li>
		<li>
			<a href="javascript:" onclick="store_rating('<?php echo $ip_address ?>', '<?php echo $post_id ?>', '5')">
				<span class="rating-icon"><i class="icon-emo-thumbsup"></i></span>
				<span class="rating-text"><?php _e('بہت اچھی ہے') ?></span>
				<span class="rating-result"><?php echo get_votes_count(''.$post_id.'','5') ?> Votes</span>
			</a>
		</li>
	</ul>

</div>