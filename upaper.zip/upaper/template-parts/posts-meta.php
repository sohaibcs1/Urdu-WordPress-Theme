<?php 
 global $xpanel;
?>
<div class="post-info pt-5 pb-5">
	<?php 
		if ( isset( $xpanel['show-zoom'] ) && $xpanel['show-zoom'] == TRUE ) {
	?>
	<span class="pull-left">
		<a href="javascript:" id="incSize" title="Increase Font Size"><i class="fa fa-search-plus"></i></a>
		<a href="javascript:" id="dcrSize" title="Increase Font Size" class="mr-10"><i class="fa fa-search-minus"></i></a>
	</span>
	<?php } ?>
	<?php 
		if ( isset( $xpanel['show-comment-count'] ) && $xpanel['show-comment-count'] == TRUE ) {
	?>
	<span class="post-comments pull-right">
		<small><?php $comments_count = wp_count_comments(get_the_ID()); ?></small>
	</span>
	<?php } ?>
	<?php 
		if ( isset( $xpanel['show-author'] ) && $xpanel['show-author'] == TRUE ) {
	?>
	<span class="post-author pull-right ml-10">
		<i class="fa fa-user pl-5"></i>
		<?php printf( '<a href="%1$s">%2$s</a>',
			esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
			esc_html( get_the_author() )
		); ?>
	</span>
	<?php } ?>
	<?php 
		if ( isset( $xpanel['show-posted-date'] ) && $xpanel['show-posted-date'] == TRUE ) {
	?>
	<?php upaper_posted_on() ?>
	<?php } ?>
	<?php 
		if ( isset( $xpanel['show-comment-count'] ) && $xpanel['show-comment-count'] == TRUE ) {
	?>
	<span class="post-comments pull-right mr-10">
		<i class="fa fa-comment-o pl-5"></i> <?php echo $comments_count->approved ?> <?php _e("تبصرے") ?>
	</span>
	<?php } ?>
	
</div>