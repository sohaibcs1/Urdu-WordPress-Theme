<?php 
/*
* Color Scheme Settinga
*/
global $xpanel;
?>
<style type="text/css">
.main-menu {
	border-top: 5px solid <?php echo $xpanel['nav-colors'] ?>;
}
.main-menu li a:hover, .main-menu li .sub-menu, .main-menu li.current-menu-item a {
	background: <?php echo $xpanel['nav-colors'] ?>;
}
button:hover,
input[type="button"]:hover,
input[type="reset"]:hover,
input[type="submit"]:hover {
	background: <?php echo $xpanel['site-colors'] ?>;
}
#news-star-sign, #closeSearchBox, .header-socil-icons ul li:hover, .breaking_head, .upaper-newsletter input[type=submit]:hover, .home-blocks .block-head .block-head-icon, .post-sharing .sharing-label, .sharing-icons ul li a:hover {
	background: <?php echo $xpanel['site-colors'] ?>;
}
.search-box {
	border: 2px solid <?php echo $xpanel['site-colors'] ?>;
}
.ticker-container, .carousel-row {
	border: 1px solid <?php echo $xpanel['site-colors'] ?>;
}
.breaking_head #left-triangle {
    border-right: 10px solid <?php echo $xpanel['site-colors'] ?>;
}
.widget .widget-title, .home-blocks .block-head {
	border-bottom:5px solid <?php echo $xpanel['site-colors'] ?>;
}
.widget .widget-title::after {
	border-color: <?php echo $xpanel['site-colors'] ?> transparent transparent transparent;
}
.related-posts-header h2{
	border-top: 2px solid <?php echo $xpanel['site-colors'] ?>;
	border-bottom: 2px solid <?php echo $xpanel['site-colors'] ?>;
}
.carousel-left {
	border-color: <?php echo $xpanel['site-colors'] ?> transparent transparent transparent;
}
.carousel-right {
	border-color: transparent transparent <?php echo $xpanel['site-colors'] ?> transparent;
}
.footer-copyrights a, .small-nav ul .current-menu-item a {
	color: <?php echo $xpanel['site-colors'] ?> !important;
}
</style>