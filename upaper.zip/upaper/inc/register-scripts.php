<?php
/*
* In this file we will register all the stykes and scripts reuired in theme.
*/
function upaper_register_scripts_styles() {
	//global $xpanel;
	//jQuery
	wp_deregister_script( 'jquery');

	//jQuery
	wp_enqueue_script( 'jquery', get_template_directory_uri() . '/js/jquery.js');

	//Bootstrap CSS
	wp_enqueue_style( 'upaper-bootstrap', get_template_directory_uri() . '/bootstrap/css/bootstrap.css' );

	//Fontellio
	wp_enqueue_style( 'upaper-fontellio', get_template_directory_uri() . '/css/fontello.css' );

	//Bootstrap RTL CSS
	//wp_enqueue_style( 'upaper-bootstrap-rtl', get_template_directory_uri() . '/bootstrap/css/bootstrap-rtl.css' );

	wp_enqueue_style( 'upaper-style', get_stylesheet_uri() );

	//Animate.css
	wp_enqueue_style( 'unews-animate-css', get_template_directory_uri() . '/css/animate.css' );

	//Font Awesome CSS
	wp_enqueue_style( 'upaper-font-awesome', get_template_directory_uri() . '/css/font-awesome/css/font-awesome.min.css' );

	//Urdu Fonts
	wp_enqueue_style( 'upaper-urdu-fonts', get_template_directory_uri() . '/css/fonts.css' );

	//Bootstrap JS
	wp_enqueue_script( 'upaper-bootstrap-j', get_template_directory_uri() . '/bootstrap/js/bootstrap.min.js');

	//Navigation.js
	wp_enqueue_script( 'upaper-navigation', get_template_directory_uri() . '/js/navigation.js', array(), '20120206', true );

	wp_enqueue_script( 'upaper-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20130115', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	//JS Browser Functions
	wp_enqueue_script( 'upaper-js-browser', get_template_directory_uri() . '/js/jquery.browser.js', array(), '', false);

	//Urdu Writing Support
	wp_enqueue_script( 'upaper-urdueditor', get_template_directory_uri() . '/js/urdueditor/jquery.UrduEditor.js');

	//News Ticker
	wp_enqueue_script( 'upaper-news-ticker', get_template_directory_uri() . '/js/jquery.liMarquee.js');
	wp_enqueue_style( 'upaper-animate-css', get_template_directory_uri() . '/css/liMarquee.css' );

	//Slick Carousel
	wp_enqueue_script( 'upaper-slick-js', get_template_directory_uri() . '/js/slick.min.js');
	wp_enqueue_style( 'upaper-slick-css', get_template_directory_uri() . '/css/slick.css' );
	wp_enqueue_script( 'upaper-slick-settings', get_template_directory_uri() . '/js/carousel-settings.js', array(), '', true);

	//Smooth Scroll
	wp_enqueue_script( 'upaper-smooth-scroll', get_template_directory_uri() . '/js/smooth-scroll.js');

	//Match Height
	wp_enqueue_script( 'upaper-match-height', get_template_directory_uri() . '/js/jquery.matchHeight.js');

	//JS Functions
	wp_enqueue_script( 'upaper-js-functions', get_template_directory_uri() . '/js/js-functions.js');

}
add_action( 'wp_enqueue_scripts', 'upaper_register_scripts_styles' );