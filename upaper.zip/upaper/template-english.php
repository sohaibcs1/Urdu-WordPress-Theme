<?php
/**
 * The template for displaying all pages.
 * Template Name: English Default
 * @package UrduPaper
 */

get_header(); ?>

	<div id="primary" class="content-area english-content">
		
		<div id="page-main" class="page-main pl-0 col-lg-11 col-md-11 col-sm-16 col-xs-16" role="main">

			<?php
			while ( have_posts() ) : the_post();

				get_template_part( 'template-parts/content', 'page' );

				// If comments are open or we have at least one comment, load up the comment template.
				if ( comments_open() || get_comments_number() ) :
					comments_template();
				endif;

			endwhile; // End of the loop.
			?>

		</div><!-- #main -->
		<div class="page-sidebar pr-0 col-lg-5 col-md-5 hidden-sm hidden-xs">
			<?php dynamic_sidebar('sidebar-single'); ?>
		</div>
	</div><!-- #primary -->

<?php
get_footer();
